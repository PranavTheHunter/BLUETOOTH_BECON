import { Slot } from "expo-router";
import React from "react";

const Layout = () => {
  return <Slot />;
};

export default Layout;
