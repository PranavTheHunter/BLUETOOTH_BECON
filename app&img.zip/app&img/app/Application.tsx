import { StyleSheet, Text, View, TextInput, TouchableOpacity, Image, Animated } from "react-native";
import React, { useEffect, useRef } from "react";
import { useRouter } from "expo-router";

const Application = () => {
  const router = useRouter();
  const fadeAnim = useRef(new Animated.Value(0)).current; // Initial opacity set to 0

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500, // 500ms fade-in duration
      useNativeDriver: true,
    }).start();
  }, []);

  const handleLogout = () => {
    router.push("/");
  };

  return (
    <Animated.View style={[styles.container, { opacity: fadeAnim }]}> 
      {/* 🔹 Header with Logout Button */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Bluetooth Beacon</Text>
        <TouchableOpacity onPress={handleLogout}>
          <Image
            source={{ uri: "https://cdn-icons-png.flaticon.com/512/1828/1828479.png" }}
            style={styles.logoutIcon}
          />
        </TouchableOpacity>
      </View>

      {/* 🔹 Title Section */}
      <Text style={styles.title}>BLUETOOTH</Text>
      <Text style={styles.subtitle}>BEACON</Text>

      {/* 🔹 Input Fields */}
      <View style={styles.inputContainer}>
        <Text style={styles.label}>BEACON NAME:</Text>
      </View>

      {/* 🔹 Description */}
      <TextInput
        style={styles.description}
        placeholder="DESCRIPTION"
        placeholderTextColor="#666"
        multiline
      />

      {/* 🔹 Speaker Icon */}
      <TouchableOpacity style={styles.iconContainer}>
        <Image
          source={{ uri: "https://cdn-icons-png.flaticon.com/512/929/929434.png" }}
          style={styles.icon}
        />
      </TouchableOpacity>
    </Animated.View>
  );
};

export default Application;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#e6f9ff", // Light blue background
    padding: 20,
    alignItems: "center",
  },
  header: {
    width: 420,
    height: 60,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#33ccff", // Blue header
    paddingHorizontal: 20,
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    elevation: 4,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#fff",
  },
  logoutIcon: {
    width: 30,
    height: 30,
  },
  title: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#000",
    marginTop: 80,
  },
  subtitle: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#000",
    textDecorationLine: "underline",
    marginBottom: 40,
  },
  inputContainer: {
    width: "100%",
    marginBottom: 20,
  },
  label: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#000",
    marginBottom: 5,
  },
  description: {
    width: "100%",
    height: 150,
    backgroundColor: "#fff",
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 10,
    fontSize: 16,
    borderColor: "#000",
    borderWidth: 1,
    textAlignVertical: "top",
  },
  iconContainer: {
    marginTop: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  icon: {
    width: 50,
    height: 50,
  },
});
